import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;

public class MemoryMeasurement {
    public static void main(String[] args) {
        MemoryMXBean memoryMXBean = ManagementFactory.getMemoryMXBean();
        MemoryUsage memoryUsage = memoryMXBean.getHeapMemoryUsage();

        long usedMemory = memoryUsage.getUsed();
        long maxMemory = memoryUsage.getMax();
        long committedMemory = memoryUsage.getCommitted();

        System.out.println("Memory Usage:");
        System.out.println("Used Memory: " + usedMemory + " bytes");
        System.out.println("Max Memory: " + maxMemory + " bytes");
        System.out.println("Committed Memory: " + committedMemory + " bytes");
    }
}
