import java.util.HashMap;
import java.util.Map;

public class TranslationFrequency {
    public static void main(String[] args) {
        String[] englishWords = {"hello", "world", "hello", "goodbye", "world"};
        
        Map<String, String> translations = createTranslationDictionary();
        Map<String, Integer> frequencyMap = calculateFrequency(englishWords, translations);

        System.out.println("English Word : French Translation : Frequency");
        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            String englishWord = entry.getKey();
            String frenchTranslation = translations.get(englishWord);
            int frequency = entry.getValue();
            System.out.println(englishWord + " : " + frenchTranslation + " : " + frequency);
        }
    }

    public static Map<String, String> createTranslationDictionary() {
        Map<String, String> translations = new HashMap<>();
        // Add English-to-French translations here
        translations.put("hello", "bonjour");
        translations.put("world", "monde");
        translations.put("goodbye", "au revoir");
        return translations;
    }

    public static Map<String, Integer> calculateFrequency(String[] words, Map<String, String> translations) {
        Map<String, Integer> frequencyMap = new HashMap<>();

        for (String word : words) {
            String translatedWord = translations.get(word);
            if (translatedWord != null) {
                if (frequencyMap.containsKey(translatedWord)) {
                    frequencyMap.put(translatedWord, frequencyMap.get(translatedWord) + 1);
                } else {
                    frequencyMap.put(translatedWord, 1);
                }
            }
        }

        return frequencyMap;
}
}
